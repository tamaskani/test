import axios from 'axios';
import { useState, useEffect, useRef } from 'react';
import http from './axiosConfig';
import './App.css';

function App() {

  const inputRef = useRef(null);

  const handleUpload = async () => {
    if (!inputRef?.current?.files?.length) {
      alert('فایل را انتخاب کنید')
      return;
    };

    const formData = new FormData();
    formData.append('image', inputRef.current.files[0]);

    const result = await http.post('/upload', formData);

    const data = await result.json()
    console.log(data);
  }

  const login = async () => {
    var data = JSON.stringify({
      "username": "admin",
      "password": "admin"
    });

    http.post('/auth/login', data, {
      headers: {
        'Content-Type': 'application/json'
      }
    })
      .then(function (response) {
        localStorage.setItem('token', response.data.token)
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  return (
    <div className='root'>
      <input type={'file'} ref={inputRef} />
      <input type={'button'} value={'ثبت'} onClick={handleUpload} />
      <input type={'button'} value={'ورود'} onClick={login} />
    </div>
  );
}

export default App;
