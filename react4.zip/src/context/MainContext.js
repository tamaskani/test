import React, {
  useState
} from 'react';

const MainContext = React.createContext();

const MianContextProvider = ({ children }) => {
  const [data, setData] = useState([]);

  const productExample = {
    product: {
      id: ''
    },
    count: 0
  }

  const removeFromCart = (product) => {
    if (data.find((item) => item.id === product.id)) {

      product.count++;
    } else {

      product['count'] = 1
      setData(prev => ([...prev, product]))
    }
  }

  const addToCart = (product) => {

    if (data.find((item) => item.id === product.id)) {
      product.count++;
    } else {

      product['count'] = 1
      setData(prev => ([...prev, product]))
    }
  }

  return (
    <MainContext.Provider value={
      {
        data,
        setData
      }
    } >
      {children}
    </MainContext.Provider>
  )

}
